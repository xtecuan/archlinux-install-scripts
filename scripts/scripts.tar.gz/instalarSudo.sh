#!/bin/sh
pacman -S --noconfirm sudo
