#!/bin/sh

groupdel $1
