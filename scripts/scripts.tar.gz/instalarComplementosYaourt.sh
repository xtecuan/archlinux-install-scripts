#!/bin/sh
yaourt -S --noconfirm aurvote customizepkg rsync pacman-color
