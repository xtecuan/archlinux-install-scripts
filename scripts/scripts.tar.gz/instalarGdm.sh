#!/bin/sh

pacman -S --noconfirm gdm
