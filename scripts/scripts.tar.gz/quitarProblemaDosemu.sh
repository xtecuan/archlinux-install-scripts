#!/bin/sh
echo 0 > /proc/sys/vm/mmap_min_addr
