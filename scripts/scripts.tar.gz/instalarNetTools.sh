#!/bin/sh

pacman -S --noconfirm net-tools
