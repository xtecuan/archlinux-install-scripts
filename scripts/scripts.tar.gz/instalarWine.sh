#!/bin/sh

pacman -S --noconfirm wine winetricks wine_gecko dosemu dosbox
