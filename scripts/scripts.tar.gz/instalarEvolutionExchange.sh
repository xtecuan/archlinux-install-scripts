#!/bin/sh

pacman -S --noconfirm evolution-exchange