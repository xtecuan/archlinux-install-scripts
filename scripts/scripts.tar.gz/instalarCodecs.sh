#!/bin/sh

pacman -S --noconfirm gstreamer0.10-plugins xine-lib gstreamer0.10-base-plugins gstreamer0.10-good-plugins gstreamer0.10-bad-plugins gstreamer0.10-ugly-plugins gstreamer0.10-ffmpeg
