#!/bin/sh

pacman -S xfce4 xfce4-goodies fortune-mod gstreamer0.10-base-plugins dbus gamin gvfs-afc thunar-volman 

