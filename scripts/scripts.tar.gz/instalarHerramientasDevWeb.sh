#!/bin/sh
pacman -S --noconfirm bluefish gedit gftp tightvnc kdevelop kdevelop-php
