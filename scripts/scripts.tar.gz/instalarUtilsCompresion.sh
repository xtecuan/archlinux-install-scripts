#!/bin/sh

pacman -S --noconfirm unrar zip unzip p7zip ntfs-3g file-roller 
