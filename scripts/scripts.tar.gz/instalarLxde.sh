#!/bin/sh

pacman -S --noconfirm lxde leafpad xarchiver obconf epdfview