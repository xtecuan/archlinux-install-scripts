#!/bin/sh
pacman -S --noconfirm xf86-video-vesa
