#!/bin/sh

pacman -S --noconfirm chromium elinks lynx firefox firefox-i18n-es-ar
