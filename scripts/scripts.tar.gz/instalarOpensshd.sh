#!/bin/sh
pacman -S --noconfirm openssh
