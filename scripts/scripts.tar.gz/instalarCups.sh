#!/bin/sh

pacman -S --noconfirm cups ghostscript gsfonts samba gutenprint foomatic-db foomatic-db-engine foomatic-db-nonfree foomatic-filters hplip splix cups-pdf
