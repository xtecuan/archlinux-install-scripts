#!/bin/sh

pacman -S --noconfirm apache php php-apache mysql
