#!/bin/sh

useradd -d /home/repo  -r -s /bin/false -U repo
