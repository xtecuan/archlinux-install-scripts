#!/bin/sh

pacman -S --noconfirm gimp gqview inkscape
