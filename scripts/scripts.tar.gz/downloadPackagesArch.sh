#!/bin/sh

archserver=10.1.0.212
export myproxy=http://$archserver:8080
export dbfile=http://$archserver/archlinux/xtesoft.pkg.db
export nameserver=10.1.0.3

export http_proxy=$myproxy
export ftp_proxy=$myproxy

km

ifconfig eth0 up

dhcpcd eth0

echo "nameserver $nameserver" > /etc/resolv.conf

/arch/setup



