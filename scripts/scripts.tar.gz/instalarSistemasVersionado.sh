#!/bin/sh

pacman -S --noconfirm subversion git mercurial tk
