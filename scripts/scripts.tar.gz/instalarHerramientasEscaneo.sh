#!/bin/sh

pacman -S --noconfirm nmap wireshark-cli wireshark-gtk ettercap kismet aircrack-ng aircrack-ng-scripts
