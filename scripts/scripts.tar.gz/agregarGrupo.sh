#!/bin/sh

groupadd $1
