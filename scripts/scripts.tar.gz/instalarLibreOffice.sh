#!/bin/sh
pacman -S --noconfirm libreoffice libreoffice-es
