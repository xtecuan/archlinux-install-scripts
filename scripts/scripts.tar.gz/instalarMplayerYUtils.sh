#!/bin/sh

yaourt -S --noconfirm mplayer mencoder
