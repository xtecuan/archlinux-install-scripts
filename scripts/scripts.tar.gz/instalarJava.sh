#!/bin/sh

pacman -S --noconfirm jdk 
