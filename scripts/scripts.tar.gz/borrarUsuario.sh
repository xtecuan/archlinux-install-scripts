#!/bin/sh

userdel -r $1
